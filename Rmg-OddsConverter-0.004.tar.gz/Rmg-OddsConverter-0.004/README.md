Rmg-OddsConverter
=================

converting odds for contracts
